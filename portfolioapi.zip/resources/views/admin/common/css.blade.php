<link rel="shortcut icon" href="{{ asset('public') }}/assets/images/favicon.ico">
<link href="{{ asset('public') }}/assets/plugins/datatables/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
<link href="{{ asset('public') }}/assets/plugins/datatables/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" />
<link href="{{ asset('public') }}/assets/plugins/datatables/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" />
<link href="{{ asset('public') }}/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="{{ asset('public') }}/assets/css/icons.css" rel="stylesheet" type="text/css">
<link href="{{ asset('public') }}/assets/css/style.css" rel="stylesheet" type="text/css">
<link href="{{ asset('public') }}/assets/plugins/summernote/summernote-bs4.css" rel="stylesheet" />
<link href="{{ asset('public') }}/assets/plugins/sweet-alert2/sweetalert2.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/8.11.8/sweetalert2.css" integrity="sha256-JHRpjLIhLC03YGajXw6DoTtjpo64HQbY5Zu6+iiwRIc=" crossorigin="anonymous" />



<script src="{{ asset('public') }}/assets/js/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/additional-methods.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>

