<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h1> Name : {{ $name }} </h1>
	<h1> Email : {{ $email }} </h1>
	<h1> Contact : {{ $contact }} </h1>
	<h1> Message : {{ $user_message }} </h1>
</body>
</html>