<script type="text/javascript">
	var base_url = "<?php echo e(url('/')); ?>";
</script>
<script src="<?php echo e(asset('public')); ?>/assets/js/popper.min.js"></script>
<script src="<?php echo e(asset('public')); ?>/assets/js/bootstrap.min.js"></script>
<script src="<?php echo e(asset('public')); ?>/assets/js/modernizr.min.js"></script>
<script src="<?php echo e(asset('public')); ?>/assets/js/detect.js"></script>
<script src="<?php echo e(asset('public')); ?>/assets/js/fastclick.js"></script>
<script src="<?php echo e(asset('public')); ?>/assets/js/jquery.slimscroll.js"></script>
<script src="<?php echo e(asset('public')); ?>/assets/js/jquery.blockUI.js"></script>
<script src="<?php echo e(asset('public')); ?>/assets/js/waves.js"></script>
<script src="<?php echo e(asset('public')); ?>/assets/js/jquery.nicescroll.js"></script>
<script src="<?php echo e(asset('public')); ?>/assets/js/jquery.scrollTo.min.js"></script>
<script src="<?php echo e(asset('public')); ?>/assets/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo e(asset('public')); ?>/assets/plugins/datatables/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo e(asset('public')); ?>/assets/plugins/datatables/dataTables.buttons.min.js"></script>
<script src="<?php echo e(asset('public')); ?>/assets/plugins/datatables/buttons.bootstrap4.min.js"></script>
<script src="<?php echo e(asset('public')); ?>/assets/plugins/datatables/jszip.min.js"></script>
<script src="<?php echo e(asset('public')); ?>/assets/plugins/datatables/pdfmake.min.js"></script>
<script src="<?php echo e(asset('public')); ?>/assets/plugins/datatables/vfs_fonts.js"></script>
<script src="<?php echo e(asset('public')); ?>/assets/plugins/datatables/buttons.html5.min.js"></script>
<script src="<?php echo e(asset('public')); ?>/assets/plugins/datatables/buttons.print.min.js"></script>
<script src="<?php echo e(asset('public')); ?>/assets/plugins/datatables/buttons.colVis.min.js"></script>
<!-- Responsive examples -->
<script src="<?php echo e(asset('public')); ?>/assets/plugins/datatables/dataTables.responsive.min.js"></script>
<script src="<?php echo e(asset('public')); ?>/assets/plugins/datatables/responsive.bootstrap4.min.js"></script>
<!-- Datatable init js -->
<script src="<?php echo e(asset('public')); ?>/assets/pages/datatables.init.js"></script>
<!-- App js -->
<script src="<?php echo e(asset('public')); ?>/assets/js/app.js"></script>
<script src="<?php echo e(asset('public')); ?>/assets/plugins/summernote/summernote-bs4.min.js"></script>

<?php /**PATH C:\xampp\htdocs\dhyey_rathod\portfolioapi\resources\views/admin/common/js.blade.php ENDPATH**/ ?>