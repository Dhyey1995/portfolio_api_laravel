<div class="left side-menu">
    <button type="button" class="button-menu-mobile button-menu-mobile-topbar open-left waves-effect">
    <i class="ion-close"></i>
    </button>
    <!-- LOGO -->
    <div class="topbar-left">
        <div class="text-center">
            
             <a href="index.html" class="logo"><img src="<?php echo e(asset('public')); ?>/assets/images/logo.png" height="24" alt="logo"></a> 
        </div>
    </div>
    <div class="sidebar-inner slimscrollleft">
        <div id="sidebar-menu">
            <ul>
                <li class="menu-title">Main</li>
                <li>
                    <a href="<?php echo e(route('home')); ?>" class="waves-effect">
                    <i class="mdi mdi-airplay"></i>
                    <span> Dashboard </span>
                    </a>
                </li>

                <li class="has_sub">
                    <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-map-marker-multiple"></i><span> Project </span></a>
                    <ul class="list-unstyled">
                        <li><a href="<?php echo e(route('add_new_project')); ?>"> Add new project</a></li>
                    </ul>
                </li>

                <li class="has_sub">
                    <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-map-marker-multiple"></i><span> Skills </span></a>
                    <ul class="list-unstyled">
                        <li><a href="<?php echo e(route('add_new_skills')); ?>"> Add new skill </a></li>
                    </ul>
                </li>


                
            </ul>
        </div>
        <div class="clearfix"></div>
    </div>
    <!-- end sidebarinner -->
</div><?php /**PATH C:\xampp\htdocs\dhyey_rathod\portfolioapi\resources\views/admin/common/sidebar.blade.php ENDPATH**/ ?>