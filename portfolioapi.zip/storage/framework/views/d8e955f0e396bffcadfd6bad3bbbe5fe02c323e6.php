<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h1> Name : <?php echo e($name); ?> </h1>
	<h1> Email : <?php echo e($email); ?> </h1>
	<h1> Contact : <?php echo e($contact); ?> </h1>
	<h1> Message : <?php echo e($user_message); ?> </h1>
</body>
</html><?php /**PATH C:\xampp\htdocs\dhyey_rathod\portfolioapi\resources\views/email/contactusadminmail.blade.php ENDPATH**/ ?>